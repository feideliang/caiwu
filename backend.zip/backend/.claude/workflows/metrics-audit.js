export const meta = {
  name: 'metrics-sql-pushdown-parallel',
  description: 'Parallel SQL pushdown audit across all 6 dashboard modules',
  phases: [{ title: 'Parallel Scan' }, { title: 'Synthesize' }],
}

phase('Parallel Scan')

const FILE = 'D:\\workspace\\caiwu04\\backend\\app\\services\\metrics_service.py'

const MODULES = [
  {
    key: 'overview',
    label: '总览驾驶舱 (Overview Dashboard)',
    prompt: `Read ${FILE} fully. Focus on the Overview Dashboard module:
- Core metrics summary (revenue, cost, gross_profit, gross_margin)
- Customer/product concentration metrics (top3, top10, top1_share)
- High margin order ratio, negative margin metrics
- Achievement rate, direct sign metrics
- Order count, loss_ratio

For EACH Python-side loop, filter, sort, or aggregate, report:
- line_range, type (filter/sort/aggregate/group/top_n)
- rows_fetched, what_it_does, sql_pushdown, effort (trivial/easy/moderate/hard), expected_speedup

Return: findings array, estimated_bottleneck (string describing the slowest part)`,
  },
  {
    key: 'trend',
    label: '趋势分析 (Trend Analysis)',
    prompt: `Read ${FILE} fully. Focus on the Trend Analysis module:
- trend_series generation (lines ~1038-1090)
- _trend_keys(), _period_members() expansion
- YoY/MoM comparison loops
- Dimension trend series (dim_trend, lines ~1094-1112)
- Consecutive growth counting
- Gross margin volatility calculation

For EACH Python-side operation, report:
- line_range, type, rows_fetched, what_it_does, sql_pushdown, effort, expected_speedup

Return: findings array, estimated_bottleneck`,
  },
  {
    key: 'dept',
    label: '部门分析 (Department Analysis)',
    prompt: `Read ${FILE} fully. Focus on the Department Analysis path (dimension="department"):
- department breakdown from AggPeriodSummary per-bgbu rows
- Per-department order counts
- Department-specific metrics (core_market_line, highest_value_market_line)
- How _is_dept_dim affects query paths (skips customer/product queries)
- department breakdown items generation

For EACH Python-side operation, report:
- line_range, type, rows_fetched, what_it_does, sql_pushdown, effort, expected_speedup

Return: findings array, estimated_bottleneck`,
  },
  {
    key: 'product',
    label: '产品分析 (Product Analysis)',
    prompt: `Read ${FILE} fully. Focus on the Product Analysis path:
- sales_product query (~13K rows per period, ~20K for 12 periods)
- Product concentration metrics (top3, top10)
- Product breakdown generation
- Negative margin product metrics
- product_line dimension vs sales_product dim_type distinction

For EACH Python-side operation, report:
- line_range, type, rows_fetched, what_it_does, sql_pushdown, effort, expected_speedup

Return: findings array, estimated_bottleneck`,
  },
  {
    key: 'customer',
    label: '客户分析 (Customer Analysis)',
    prompt: `Read ${FILE} fully. Focus on the Customer Analysis path:
- Customer query (now using ROW_NUMBER window function, Top 30 per period)
- Customer concentration metrics (top3, top10, top1_share)
- Customer breakdown (Top 10)
- Customer concentration MoM change calculation
- The __total__ denominator optimization

For EACH Python-side operation, report:
- line_range, type, rows_fetched, what_it_does, sql_pushdown, effort, expected_speedup

Also verify: does the current ROW_NUMBER() window function actually push the filter to SQL, or does it still fetch all rows and filter in Python?

Return: findings array, estimated_bottleneck`,
  },
  {
    key: 'change',
    label: '变动分析 (Change/Margin Analysis)',
    prompt: `Read ${FILE} fully. Focus on the Margin Change Analysis module (lines ~1150-1288):
- Margin change impact decomposition (structure vs margin impact)
- Per-dimension comparison between current and base period
- New/exit/continuing category classification
- MoM of impact factors (previous period comparison loop)
- MarginChangeSummary aggregation

For EACH Python-side operation, report:
- line_range, type, rows_fetched, what_it_does, sql_pushdown, effort, expected_speedup

Return: findings array, estimated_bottleneck`,
  },
  {
    key: 'orders',
    label: '订单分析 (Order Summary & AggOrderSummary)',
    prompt: `Read ${FILE} fully. Focus on the Order Summary module:
- AggOrderSummary query with GROUP BY (period, order_id) - ~30K rows after aggregation
- Order-based metrics: order_count, loss_ratio
- Negative margin order ratio, YoY/MoM change
- Per-dimension order counts (period_orders_dim)
- High margin order ratio calculation

For EACH Python-side operation, report:
- line_range, type, rows_fetched, what_it_does, sql_pushdown, effort, expected_speedup

Return: findings array, estimated_bottleneck`,
  },
]

const schema = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          line_range: { type: 'string' },
          type: { type: 'string' },
          rows_fetched: { type: 'string' },
          what_it_does: { type: 'string' },
          sql_pushdown: { type: 'string' },
          effort: { type: 'string' },
          expected_speedup: { type: 'string' },
        },
        required: ['line_range', 'type', 'rows_fetched', 'what_it_does', 'sql_pushdown', 'effort', 'expected_speedup'],
      },
    },
    estimated_bottleneck: { type: 'string' },
  },
  required: ['findings', 'estimated_bottleneck'],
}

const results = await parallel(MODULES.map(m => () =>
  agent(m.prompt, { label: `scan:${m.key}`, phase: 'Parallel Scan', schema }).then(r => ({ ...r, key: m.key, label: m.label }))
))

const allFindings = {}
for (const r of results.filter(Boolean)) {
  allFindings[r.key] = { label: r.label, findings: r.findings, bottleneck: r.estimated_bottleneck }
}

log(`Scan complete: ${results.filter(Boolean).reduce((s, r) => s + r.findings.length, 0)} total findings across ${results.length} modules`)

phase('Synthesize')

const synthesized = await agent(`
Synthesize the following parallel scan results into a unified prioritized optimization plan.

Each module was scanned independently for Python-side operations that can be pushed down to SQL.
Here are the results:

${JSON.stringify(allFindings, null, 2)}

Create a prioritized list of optimizations. Each should include:
1. priority (1 = highest)
2. module (which dashboard module)
3. title (short description)
4. current_lines (approximate line numbers in metrics_service.py)
5. current_behavior (what Python is doing now)
6. sql_change (exact SQL change needed)
7. expected_speedup (rough time savings)
8. risk (low/medium/high - does it change result values?)
9. affected_modules (which dashboard modules benefit)

Prioritize by:
- Impact (rows reduced x frequency of query path)
- Effort (trivial first)
- Risk (low risk first)

Also include a summary with:
- total_recs
- estimated_total_speedup (before/after for the most common query: department + cumulative + yoy)
- highest_impact_item

Return JSON with: recommendations (array), summary (object).`, {
  label: 'synthesize-plan',
  phase: 'Synthesize',
  schema: {
    type: 'object',
    properties: {
      recommendations: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            priority: { type: 'number' },
            module: { type: 'string' },
            title: { type: 'string' },
            current_lines: { type: 'string' },
            current_behavior: { type: 'string' },
            sql_change: { type: 'string' },
            expected_speedup: { type: 'string' },
            risk: { type: 'string' },
            affected_modules: { type: 'array', items: { type: 'string' } },
          },
          required: ['priority', 'module', 'title', 'current_lines', 'current_behavior', 'sql_change', 'expected_speedup', 'risk'],
        },
      },
      summary: {
        type: 'object',
        properties: {
          total_recs: { type: 'number' },
          estimated_total_speedup: { type: 'string' },
          highest_impact_item: { type: 'string' },
        },
        required: ['total_recs', 'estimated_total_speedup', 'highest_impact_item'],
      },
    },
    required: ['recommendations', 'summary'],
  },
})

log(`Synthesis complete: ${synthesized.recommendations.length} recommendations`)

return { module_findings: allFindings, plan: synthesized }
